# *Keyboard Simulator*<br>
![markdown logo](https://freesvg.org/img/1312973798-keyboard.png)
<br>
git clone https://github.com/ArApus/Keyboard_Simulator.git <br> 
git checkout dev <br>
pip install -r requirements.txt<br> 
python3 main.py

