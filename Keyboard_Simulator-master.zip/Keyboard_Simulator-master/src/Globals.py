import pygame


class Globals:

    level0 = ["j", "k", "_"]
    level1 = ["f", "d"]
    level2 = level0 + level1

    level3 = ["l", ';', "_"]
    level4 = ["a", "s"]
    level5 = level3 + level4

    level6 = level2 + level5 # Combining the previous two blocks

    level7 = ["g", "h", "_"]
    level8 = ["u", "y", "_"]
    level9 = level7 + level8

    level10 = ["r", "t"]
    level11 = ["e", "w", '_']
    level12 = level10 + level11

    level13 = level9 + level12 # Combining the previous two blocks

    level14 = level6 + level13 # Combining the previous four blocks

    level15 = ["i", "o"]
    level16 = ["q", "p"]
    level17 = level15 + level16

    level18 = ["[", "]", "{"]
    level19 = ["}", "(", ")"]
    level20 = level18 + level19

    level21 = level17 + level20 # Combining the previous two blocks

    level22 = level14 + level21 # Combining the previous six blocks

    level23 = ["z", "x"]
    level24 = ["n", "m"]
    level25 = level23 + level24

    level26 = ["c", "v"]
    level27 = ["b", "n"]
    level28 = level26 + level27

    level29 = level25 + level28 # Combining the previous two blocks

    level30 = level22 + level29 # Combining the previous eight blocks

    level31 = [",", "."]
    level32 = ["<", ">"]
    level33 = level31 + level32

    level34 = ["/", "?"]

    level35 = level33 + level34 # Combining the previous two blocks

    level36 = level30 + level35 # Combining the previous ten blocks

    Junior_levels = [
                    level1, level2, level3,
                    level4, level5, level6,
                    level7, level8, level9
                    ]
    Middle_levels = [
                    level10, level11, level12,
                     level13, level14, level15,
                    level16, level17, level18
                    ]
    Senior_levels = [
                    level19, level20, level21,
                    level22, level23, level24,
                    level25, level26, level27
                    ]
    Developer_levels = [level28, level29, level30,
                   level31, level32, level33,
                   level34, level35, level36]

    THE_FIRST_LEVEL = 0
    THE_LAST_LEVEL = 8

    COORD_OF_STRING = (400, 200)
    COORD_OF_STAT = (400, 20)
    COORD_PRESS_END = (50, 20)
    COORD_OF_ONLINE = (400, 30)

    COLOUR_SCREEN_FILL = (50, 150, 50)
    COLOUR_OF_MENU_TEXT = (0, 0, 0)
    COLOUR_OF_MENU_RECTANGLE = (0, 0, 0)
    COLOUR_OF_STRING = (0, 0, 0)
    COLOUR_OF_CORRECT_STRING = (0, 255, 0)
    COLOUR_OF_WARNING = (255, 0, 0)
    COLOUR_OF_STATISTICS = (0, 0, 0)
    COLOUR_WRONG_ANSWER = (240, 0, 255)
    BLUE = (0, 0, 255)

    SYM_HESH_COUNTER = 66
    pygame.init()
    size = (1440, 800)
    screen = pygame.display.set_mode(size,  pygame.RESIZABLE)
    pygame.display.set_caption("Уроки Быстрой Печати")
    img = pygame.image.load("src/grad.jpg")
    img_cat = pygame.image.load("src/cat.jpg")
    pygame.display.set_icon(img)

    ARIAL_30 = pygame.font.SysFont('arial', 40)
    ARIAL_50 = pygame.font.SysFont('arial', 50)
    ARIAL_70 = pygame.font.SysFont('arial', 70)
    ARIAL_90 = pygame.font.SysFont('arial', 90)
    RUNNING = True
    LEVEL = 0
    LEN_STRING = 30
