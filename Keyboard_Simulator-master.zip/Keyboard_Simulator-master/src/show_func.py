import src.Globals as Globals
import src.hash_func as hf
import keyboard
import openpyxl
import pygame
import random
import src.stat_func as stf
import src.supp_func as sf
import time


def cat_show():
    """Shows cat when user make a mistake"""
    cat_list = ["src/cat4.jpg", "src/cat.jpg", "src/cat_black.jpg"]
    cat_surf = pygame.image.load(random.choices(cat_list)[0])
    cat_surf.set_colorkey((255, 255, 255))
    cat_rect = cat_surf.get_rect(bottomright=(400, 800))
    Globals.Globals.screen.blit(cat_surf, cat_rect)
    pygame.display.update()



def help_show():
    """Shows Help Information"""
    Globals.Globals.screen.blit(Globals.Globals.img, (0, 0))

    c = Globals.Globals.COLOUR_OF_MENU_TEXT
    f0 = Globals.Globals.ARIAL_50.render("ESC to Exit", True, c)
    f1 = Globals.Globals.ARIAL_50.render('To Exit During the game: press key "esc"', True, c)
    f2 = Globals.Globals.ARIAL_50.render('To select option press "Enter"', True, c)
    f3 = Globals.Globals.ARIAL_50.render('To Manage Statistics and Hash: press key "up" and "down" ', True, c)
    f4 = Globals.Globals.ARIAL_50.render('During the game "_" means "space"', True, c)
    f5 = Globals.Globals.ARIAL_50.render('Load file in "txt" format', True, c)
    f_list = [f1, f2, f3, f4, f5]
    while not keyboard.is_pressed("esc"):
        Globals.Globals.screen.blit(f0, Globals.Globals.COORD_PRESS_END)
        delta, coord_x, coord_y = 100, 200, 100
        for i in range(5):
            Globals.Globals.screen.blit(f_list[i], (coord_x, coord_y))
            coord_y += delta
        pygame.display.update()


def esc_to_end_show():
    """Draws 'ESC to Exit'"""
    follow = Globals.Globals.ARIAL_70.render("ESC to Exit", True, Globals.Globals.COLOUR_OF_MENU_TEXT)
    Globals.Globals.screen.blit(follow, Globals.Globals.COORD_PRESS_END)
    pygame.display.update()


def level_num_show():
    """Draws 'Choose level number' """
    coord_write_number_x = Globals.Globals.size[0] // 2 - 250
    coord_write_number_y = 100
    delta = 100
    string1 = "Choose level number between"
    string2 = f"{Globals.Globals.THE_FIRST_LEVEL} and {Globals.Globals.THE_LAST_LEVEL}"
    follow = Globals.Globals.ARIAL_70.render(string1, True, Globals.Globals.COLOUR_OF_MENU_TEXT)
    nums = Globals.Globals.ARIAL_70.render(string2, True, Globals.Globals.COLOUR_OF_MENU_TEXT)

    Globals.Globals.screen.blit(follow, (coord_write_number_x, coord_write_number_y))
    Globals.Globals.screen.blit(nums, (coord_write_number_x, coord_write_number_y + delta))
    pygame.display.update()


def type_level_show():
    """Draws 'Choose the difficulty level'"""
    """Draws 'press "f" Junior'"""
    """Draws 'press "s" Middle"""
    """Draws 'press "t" Senior'"""
    """Draws 'press "d" The Best Developer'"""
    coord_write_number_x, coord_write_number_y = Globals.Globals.size[0] // 2 - 250, 100
    delta = 100
    follow = Globals.Globals.ARIAL_70.render("Choose the difficulty level:", True, Globals.Globals.COLOUR_OF_STRING)
    f = Globals.Globals.ARIAL_70.render('press "f" Junior', True, Globals.Globals.COLOUR_OF_STRING)
    s = Globals.Globals.ARIAL_70.render('press "s" Middle', True, Globals.Globals.COLOUR_OF_STRING)
    t = Globals.Globals.ARIAL_70.render('press "t" Senior', True, Globals.Globals.COLOUR_OF_STRING)
    d = Globals.Globals.ARIAL_70.render('press "d" The Best Developer', True, Globals.Globals.COLOUR_OF_STRING)
    Globals.Globals.screen.blit(follow, (coord_write_number_x, coord_write_number_y))
    Globals.Globals.screen.blit(f, (coord_write_number_x + delta, coord_write_number_y + delta))
    Globals.Globals.screen.blit(s, (coord_write_number_x + delta, coord_write_number_y + 2 * delta))
    Globals.Globals.screen.blit(t, (coord_write_number_x + delta, coord_write_number_y + 3 * delta))
    Globals.Globals.screen.blit(d, (coord_write_number_x + delta, coord_write_number_y + 4 * delta))
    pygame.display.update()


def wrong_answer_show_rect():
    """Draws 'Wrong'; Uses in when wrong key"""
    lenght = 200
    cover_rect = (0, Globals.Globals.size[1] - lenght, Globals.Globals.size[0], lenght)
    pygame.draw.rect(Globals.Globals.screen, Globals.Globals.COLOUR_WRONG_ANSWER, cover_rect)
    follow = Globals.Globals.ARIAL_70.render("Wrong", True, Globals.Globals.COLOUR_OF_STRING)
    Globals.Globals.screen.blit(follow, (Globals.Globals.size[0] // 2 - 200, Globals.Globals.size[1] - 150))
    pygame.display.update()


def correct_string_show(correct_string, lci):
    """Draws correct string"""
    follow = Globals.Globals.ARIAL_70.render(correct_string, True, Globals.Globals.COLOUR_OF_STRING)
    Globals.Globals.screen.blit(follow, Globals.Globals.COORD_OF_STRING)
    follow = Globals.Globals.ARIAL_70.render(correct_string[:lci], True, Globals.Globals.COLOUR_OF_CORRECT_STRING)
    Globals.Globals.screen.blit(follow, Globals.Globals.COORD_OF_STRING)
    pygame.display.update()


def online_stat_show(start_time, lci, mistakes):
    """Draws online stat"""
    online_delta = time.time() - start_time
    speed = sf.to_fixed(lci * 60 / online_delta, 1)
    s = f"speed={speed} mistakes={mistakes}"
    follow = Globals.Globals.ARIAL_70.render(s, True, Globals.Globals.COLOUR_OF_STATISTICS)
    Globals.Globals.screen.blit(follow, Globals.Globals.COORD_OF_ONLINE)
    pygame.display.update()


def no_hash_show():
    """Draw 'NO HASH'"""
    pygame.time.wait(75)
    follow = Globals.Globals.ARIAL_30.render("NO HASH", True, Globals.Globals.COLOUR_OF_WARNING)
    Globals.Globals.screen.blit(follow, (Globals.Globals.COORD_OF_STAT[0], 20))
    pygame.display.update()


def no_hash_more_show():
    """Draw 'NO HASH MORE'"""
    follow = Globals.Globals.ARIAL_30.render("NO HASH MORE", True, Globals.Globals.COLOUR_OF_WARNING)
    Globals.Globals.screen.blit(follow, (Globals.Globals.COORD_OF_STAT[0] + 250, Globals.Globals.COORD_OF_STAT[1]))
    pygame.display.update()


def hash_show():
    """Draws hash"""
    flag_first, step_y, step_x, delta_y, delta_x = 1, 60, 0, 47, 200
    wb = openpyxl.reader.excel.load_workbook(filename="src/hash.xlsx")
    wb.active = 0
    sheet = wb.active
    current_a1_val = a1_val = sheet["A1"].value
    sf.fill_gradient()
    while not keyboard.is_pressed("esc"):
        esc_to_end_show()
        up, down = sf.up_down_pressed()
        if up or down:
            if (up and current_a1_val == a1_val) or (down and current_a1_val == 2):
                no_hash_more_show()
            else:
                current_a1_val, flag_first, step_x, step_y = hf.hash_processing_up_down(current_a1_val, up)
        if flag_first:
            flag_first = hf.hash_iter(current_a1_val, step_x, step_y, delta_x, delta_y)


def no_stat_show():
    """Draws 'NO STAT'"""
    pygame.time.wait(75)
    follow = Globals.Globals.ARIAL_30.render("NO STAT", True, Globals.Globals.COLOUR_OF_WARNING)
    Globals.Globals.screen.blit(follow, (Globals.Globals.COORD_OF_STAT[0], 20))
    pygame.display.update()


def no_stat_more_show():
    """Draws 'NO STAT MORE'"""
    pygame.time.wait(75)
    follow = Globals.Globals.ARIAL_30.render("NO STAT MORE", True, Globals.Globals.COLOUR_OF_WARNING)
    Globals.Globals.screen.blit(follow, (Globals.Globals.COORD_OF_STAT[0] + 500, Globals.Globals.COORD_OF_STAT[1]))
    pygame.display.update()

def stat_new_list(current_a1_val, a1_val, delta_x, delta_y):
    esc_to_end_show()
    up, down = sf.up_down_pressed()
    pygame.time.wait(100)
    flag_first = 1
    if up or down:
        if (up and current_a1_val == a1_val) or (down and current_a1_val == 2):
            no_stat_more_show()
        else:
            current_a1_val, flag_first, step_y, step_x = stf.stat_processing_up_down(current_a1_val, up)
    if flag_first:
        flag_first = stf.stat_flag_first(current_a1_val, step_x, step_y, delta_x, delta_y)


def process_stat_else(a1_val, flag_first, step_x, step_y, delta_x, delta_y):
    current_a1_val = a1_val
    while not keyboard.is_pressed("esc"):
        esc_to_end_show()
        up, down = sf.up_down_pressed()
        pygame.time.wait(100)
        if up or down:
            if (up and current_a1_val == a1_val) or (down and current_a1_val == 2):
                no_stat_more_show()
            else:
                current_a1_val, flag_first, step_y, step_x = stf.stat_processing_up_down(current_a1_val, up)
        if flag_first:
            flag_first = stf.stat_flag_first(current_a1_val, step_x, step_y, delta_x, delta_y)


def stat_show():
    """Draws stat"""
    flag_first, step_y, step_x, delta_y, delta_x = 1, 60, 0, 40, 200
    wb = openpyxl.reader.excel.load_workbook(filename="src/statistic.xlsx")
    wb.active = 0
    sheet = wb.active
    a1_val = sheet["A1"].value
    sf.fill_gradient()
    if a1_val is None or a1_val == 1:
        sheet["A1"].value = 1
        while not keyboard.is_pressed("esc"):
            esc_to_end_show()
            no_stat_show()
    else:
        process_stat_else(a1_val, flag_first, step_x, step_y, delta_x, delta_y)
