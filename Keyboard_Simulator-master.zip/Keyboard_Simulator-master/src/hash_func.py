import datetime
import src.Globals as Globals
import openpyxl
import pygame
import src.supp_func as sf


def hash_append_new_date(new, new_today, sym_num):
    """Append a new date; Appends in new date information of mistakes"""
    wb = openpyxl.reader.excel.load_workbook(filename="src/hash.xlsx")
    wb.active = 0
    sheet = wb.active
    sheet["A1"].value = new
    sheet.cell(row=int(1), column=int(new)).value = new_today
    sheet.cell(row=int(sym_num), column=int(new)).value = 1
    sheet["B" + str(sym_num)].value = 1
    wb.save("src/hash.xlsx")
    wb.close()


def hash_find_sym_num(sym):
    """Finds sym in hash table; Returns relevant num and incorrect sym flag"""
    wb = openpyxl.reader.excel.load_workbook(filename="src/hash.xlsx")
    wb.active = 0
    sheet = wb.active
    incorrect_sym_flag = 1
    sym_num = 66
    for i in range(2, Globals.Globals.SYM_HESH_COUNTER):
        if sym == sheet['A'+str(i)].value:
            sym_num = i
            incorrect_sym_flag = 0
            break
    return sym_num, incorrect_sym_flag


def hash_append_exist_date(sym_num, a1_val):
    """Appends information of mistakes on last date"""
    wb = openpyxl.reader.excel.load_workbook(filename="src/hash.xlsx")
    wb.active = 0
    sheet = wb.active
    if sheet.cell(row=int(sym_num), column=int(a1_val)).value is None:
        sheet.cell(row=int(sym_num), column=int(a1_val)).value = 0
    if sheet["B" + str(sym_num)].value is None:
        sheet["B" + str(sym_num)].value = 0

    sheet.cell(row=int(sym_num), column=int(a1_val)).value += 1
    sheet["B" + str(sym_num)].value += 1
    wb.save("src/hash.xlsx")
    wb.close()


def hash_append(sym):
    """Appends mistake in hash"""
    wb = openpyxl.reader.excel.load_workbook(filename="src/hash.xlsx")
    wb.active = 0
    sheet = wb.active
    sym_num, incorrect_sym_flag = hash_find_sym_num(sym)
    if incorrect_sym_flag:
        return -1
    new_today = sf.change_minus_on_point(datetime.date.today())
    a1_val = sheet["A1"].value
    if a1_val is None:
        a1_val = sheet["A1"].value = 1
    last_date = sheet.cell(row=1, column=int(a1_val)).value
    wb.save("src/hash.xlsx")
    wb.close()
    if last_date == new_today:
        hash_append_exist_date(sym_num, a1_val)
    else:
        new = a1_val + 1
        hash_append_new_date(new, new_today, sym_num)


def hash_processing_up_down(current_a1_val, up):
    """Processing with key 'up' and 'down'; Allows or Forbids """
    pygame.time.wait(75)
    flag_first = 1
    step_x = 0
    step_y = 60
    change = -1 + 2 * up
    current_a1_val += change
    Globals.Globals.screen.blit(Globals.Globals.img, (0, 0))
    pygame.display.update()
    return current_a1_val, flag_first, step_x, step_y


def hash_iter(current_a1_val, step_x, step_y, delta_x, delta_y):
    """Draw hash on current; return flag iteration = 0"""
    wb = openpyxl.reader.excel.load_workbook(filename="src/hash.xlsx")
    wb.active = 0
    sheet = wb.active
    sf.draw_line(str(sheet.cell(row=1, column=int(current_a1_val)).value),
                 Globals.Globals.COORD_OF_STAT[0] + step_x, Globals.Globals.COORD_OF_STAT[1])
    for roww in range(2, Globals.Globals.SYM_HESH_COUNTER):
        if Globals.Globals.COORD_OF_STAT[1] + step_y > Globals.Globals.size[1] - delta_y * 3:
            step_y = 60
            step_x += delta_x
        if sheet.cell(row=roww, column=current_a1_val).value is None:
            sheet.cell(row=roww, column=current_a1_val).value = 0
        count_mistakes = str(sheet.cell(row=roww, column=current_a1_val).value)
        symbol = str(sheet.cell(row=roww, column=1).value)
        line = symbol + " :  " + count_mistakes
        sf.draw_line(line, Globals.Globals.COORD_OF_STAT[0] + step_x, Globals.Globals.COORD_OF_STAT[1] + step_y)
        step_y += delta_y
    flag_iter = 0
    return flag_iter
