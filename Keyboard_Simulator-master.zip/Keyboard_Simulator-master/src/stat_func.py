import datetime
import src.Globals as Globals
import openpyxl
import pygame
import src.supp_func as sf


def stat_append_exisst_date(a1_val, speed, mistakes):
    """Appends speed and mistakes with last date"""
    wb = openpyxl.reader.excel.load_workbook(filename="src/statistic.xlsx")
    wb.active = 0
    sheet = wb.active
    b_num = sheet["B" + str(a1_val)].value
    sheet.cell(row=int(a1_val), column=int(b_num)).value = str(speed) + 5 * " " + str(mistakes)
    sheet["B" + str(a1_val)].value = b_num + 1
    wb.save("src/statistic.xlsx")
    wb.close()


def stat_append_new_date(new, new_today, speed, mistakes):
    """Appends speed and mistakes with new date"""
    wb = openpyxl.reader.excel.load_workbook(filename="src/statistic.xlsx")
    wb.active = 0
    sheet = wb.active
    sheet["A1"].value = new
    sheet["A" + str(new)].value = new_today
    sheet["B" + str(new)].value = 4
    sheet["C" + str(new)].value = str(speed) + 5 * " " + str(mistakes)
    wb.save("src/statistic.xlsx")
    wb.close()


def stat_append(speed, mistakes):
    """Appends speed and mistakes to statistics"""
    wb = openpyxl.reader.excel.load_workbook(filename="src/statistic.xlsx")
    wb.active = 0
    sheet = wb.active
    tod = datetime.date.today()
    new_today = sf.change_minus_on_point(tod)
    a1_val = sheet["A1"].value
    if a1_val is None:
        a1_val = sheet["A1"].value = 1
    last_date = sheet["A" + str(a1_val)].value
    if last_date == new_today:
        stat_append_exisst_date(a1_val, speed, mistakes)
    else:
        new = a1_val + 1
        stat_append_new_date(new, new_today, speed, mistakes)


def stat_processing_up_down(current_a1_val, up):
    """Processing key 'up' and key 'down';"""
    change = -1 + 2 * up
    current_a1_val += change
    flag_first_iter = 1
    step_y = 60
    step_x = 0
    Globals.Globals.screen.blit(Globals.Globals.img, (0, 0))
    pygame.display.update()
    return current_a1_val, flag_first_iter, step_y, step_x


def stat_flag_first(current_a1_val, step_x, step_y, delta_x, delta_y):
    """Draws current date statistics; Returns flag_first"""
    wb = openpyxl.reader.excel.load_workbook(filename="src/statistic.xlsx")
    wb.active = 0
    sheet = wb.active
    sf.draw_line(str(sheet.cell(row=int(current_a1_val), column=1).value),
                 Globals.Globals.COORD_OF_STAT[0] + step_x, Globals.Globals.COORD_OF_STAT[1])
    b_i_val = sheet["B" + str(current_a1_val)].value
    if b_i_val is None:
        b_i_val = sheet["B" + str(current_a1_val)].value = 2
    for col in range(b_i_val - 1, 2, -1):
        if Globals.Globals.COORD_OF_STAT[1] + step_y > Globals.Globals.size[1] - delta_y * 3:
            step_y = 60
            step_x += delta_x
        line = str(sheet.cell(row=int(current_a1_val), column=col).value)
        sf.draw_line(line, Globals.Globals.COORD_OF_STAT[0] + step_x, Globals.Globals.COORD_OF_STAT[1] + step_y)
        step_y += delta_y
    flag_first = 0
    return flag_first
