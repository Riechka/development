import src.Globals as Globals
import keyboard
import pygame


def change_space_on_underline(line):
    new_line = ""
    for sym in line:
        if sym == " ":
            sym = "_"
        new_line = new_line + sym
    return new_line


def space_underline(correct_string, lci):
    """Changes space on underline"""
    follow = Globals.Globals.ARIAL_70.render(correct_string[:lci] + "_", True, Globals.Globals.COLOUR_OF_CORRECT_STRING)
    Globals.Globals.screen.blit(follow, Globals.Globals.COORD_OF_STRING)
    pygame.display.update()


def fill_gradient():
    """Fill gradient; Update Display"""
    Globals.Globals.screen.blit(Globals.Globals.img, (0, 0))
    pygame.display.flip()


def change_minus_on_point(tod):
    """Change minus in string on point"""
    new_today = ""
    for sym in str(tod):
        if sym == "-":
            sym = "."
        new_today = new_today + sym
    return new_today


def draw_line(line, coord_x, coord_y):
    """Draw string with coord x and y"""
    follow = Globals.Globals.ARIAL_50.render(line, True, Globals.Globals.COLOUR_OF_STATISTICS)
    Globals.Globals.screen.blit(follow, (coord_x, coord_y))
    pygame.display.update()


def to_fixed(num_obj, digits=0):
    """Leave digits after comma"""
    return f"{num_obj:.{digits}f}"


def no_option():
    """Write: None of the Options"""
    follow = Globals.Globals.ARIAL_70.render("None of the Options. Try Again", True, Globals.Globals.COLOUR_OF_WARNING)
    Globals.Globals.screen.blit(follow, (Globals.Globals.COORD_OF_STRING[0], Globals.Globals.COORD_PRESS_END[1]))
    pygame.display.update()


def up_down_pressed():
    """returns tuple (if pressed) up,down"""
    return keyboard.is_pressed("up"), keyboard.is_pressed("down")
